
package modelo;


public class UsuarioDeServicio {
    
}

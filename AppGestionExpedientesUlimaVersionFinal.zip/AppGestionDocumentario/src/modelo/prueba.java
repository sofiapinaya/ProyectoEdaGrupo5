package modelo;
    import java.io.File;
    import java.io.FileWriter;
    import java.io.IOException;
    import java.util.Date;

public class prueba {
    public static void main(String[] args) {
        /*SistemaMain.registrarAdministrador("Laura Gonzales", "LauraPro", "1234");
        AdministradorDelSistema adm = SistemaMain.autenticarUsuario("LauraPro", "1234");
        adm.registrarUsuario("78245667", "Pepe Paredes", "789 451 231", "pepe@gmail.com");
        adm.registrarUsuario("12456784", "David Callalli", "456 184 790", "david@gmail.com");
        if (adm.existeUsuario("1245678")) {
            System.out.println("Si existe");
        }
        else{
            System.out.println("No existe");
        }
        adm.registrarDependencia("A");
        adm.registrarDependencia("B");
        
        adm.registrarExpedienteEnDependencia(5, "78245667", "Reclamo sistema", "A");
        adm.registrarExpedienteEnDependencia(0, "12456784", "Queja personal", "A");
        adm.registrarExpedienteEnDependencia(2, "12456784", "Reclamo producto", "A");
        
        adm.registrarExpedienteEnDependencia(3, "78245667", "Reclamo sistema", "B");
        adm.registrarExpedienteEnDependencia(0, "12456784", "Queja personal", "B");
        
        Dependencia da = adm.obtenerDependencia("A");
        da.verTramitesDepedencia();
        da.finalizarTramitePrioridad();
        da.verTramitesDepedencia();
        
        System.out.println("");
        
        Dependencia db = adm.obtenerDependencia("B");
        db.verTramitesDepedencia();
        db.finalizarTramitePrioridad();
        db.verTramitesDepedencia();
        
        System.out.println("");
        ExpedientesFinalizados.verFinalizados();
        
        System.out.println("");
        System.out.println("--------------------------------------------");
        System.out.println("");
        
        adm.moverExpedientePrioridad("A", "B");
        da.verTramitesDepedencia();
        db.verTramitesDepedencia();
        
        System.out.println("");
        ExpedientesFinalizados.verFinalizados();*/
    }
}

package modelo;

public class AdministradorDelSistema {

    // Credenciales fijas para la autenticación
    private static final String nombreUsuarioCorrecto = "Juan Gonzales Olivera Zavalaga";
    private static final String contraseñaCorrecta = "SofiayValeriaSonMejoresQueJuan";

    // Método estático para autenticar
    public static boolean autenticar(String usuario, String contraseña) {
        return usuario.equals(nombreUsuarioCorrecto) && contraseña.equals(contraseñaCorrecta);
    }
}

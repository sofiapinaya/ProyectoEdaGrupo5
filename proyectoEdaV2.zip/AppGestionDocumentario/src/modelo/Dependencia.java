
package modelo;
import tda.Lista;
import tda.Cola;


public class Dependencia {
    private String nombre;
    private int id_dependencia;
    private Lista<PersonalDeDependencia> personal;
    private Cola<Expediente> expedientes;
    
}

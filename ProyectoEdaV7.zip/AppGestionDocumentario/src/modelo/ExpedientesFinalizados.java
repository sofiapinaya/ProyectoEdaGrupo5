package modelo;
    import tda.*;

public abstract class ExpedientesFinalizados {
    public static Lista<Expediente> expFinalizados = new Lista();
    
    public static void ingresarFinalizado(Expediente exp){
        expFinalizados.agregar(exp);
    }
    
    public static void verFinalizados(){
        if (!expFinalizados.esVacia()) {
            Nodo<Expediente> ptr = expFinalizados.getCabeza();
            while(ptr != null){
                Expediente actual = ptr.getElemento();
                System.out.println(actual.getID() + " / " + actual.getPrioridad() + " / " + actual.getHoraFin() + " / " + actual.getDepenActual().getNombre());
                ptr = ptr.getSgteNodo();
            }
        }
    }
    
    public static Expediente eliminarUltimoFinalizado(){
        int posFinal = expFinalizados.longitud();
        Expediente resp = expFinalizados.iesimo(posFinal);
        expFinalizados.eliminar(posFinal);
        return resp;
    }
}

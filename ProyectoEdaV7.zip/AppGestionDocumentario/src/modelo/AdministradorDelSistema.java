package modelo;
    import tda.*;

public class AdministradorDelSistema {
    private Lista<Dependencia> listDependencias;
    private Pila<Usuario> PilaUsuarios;
    private String nombreApellido;
    private String nomUsuario, contraseña;

    public AdministradorDelSistema(String nombreApellido, String nomUsuario, String contraseña) {
        this.nombreApellido = nombreApellido;
        this.nomUsuario = nomUsuario;
        this.contraseña = contraseña;
        this.listDependencias = new Lista();
        this.PilaUsuarios = new Pila();
    }
    
    public void registrarUsuario(String DNI, String nombreApellido, String telefono, String email){
        Usuario nuevo = new Usuario(DNI, nombreApellido, telefono, email);
        this.PilaUsuarios.push(nuevo);
    }
    
    public void registrarDependencia(String nombre){
        Dependencia nuevo = new Dependencia(nombre);
        this.listDependencias.agregar(nuevo);
    }
    
    public void registrarExpedienteEnDependencia(int prioridad, String DNIinteresado, String asunto, String nombreDependencia){ //int prioridad, Usuario interesado, String asunto, String referencia -> contructor expediente
        Pila<Usuario> aux = new Pila();
        while(!this.PilaUsuarios.isEmpty()){
            Usuario actual = this.PilaUsuarios.pop();
            if (actual.getDNI().equals(DNIinteresado)) {
                Nodo<Dependencia> ptr = this.listDependencias.getCabeza();
                while(ptr != null && !ptr.getElemento().getNombre().equals(nombreDependencia)){
                    ptr = ptr.getSgteNodo();
                }
                if (ptr != null) {
                    ptr.getElemento().ingresarTramite(prioridad, actual, asunto);
                }     
            }
            aux.push(actual);
        }
        while(!aux.isEmpty()){
            this.PilaUsuarios.push(aux.pop());
        }
    }
    
    public Dependencia obtenerDependencia(String nombreDependencia){ //retornar la dependencia (para hacer cambios) a partir de su nombre
        Nodo<Dependencia> ptr = this.listDependencias.getCabeza();
        while(ptr != null && !ptr.getElemento().getNombre().equals(nombreDependencia)){
            ptr = ptr.getSgteNodo();
        }
        if(ptr.getElemento() != null){
            return ptr.getElemento();
        }
        return null;
    }
    
    public void moverExpedienteporID(String nombreDependenciaDesde, String nombreDependenciaHasta, String UID){
        Dependencia desde = this.obtenerDependencia(nombreDependenciaDesde);
        Dependencia hasta = this.obtenerDependencia(nombreDependenciaHasta);
        
        if (desde != null && hasta != null) {
            desde.finalizarTramiteConID(UID);
            Expediente exp = ExpedientesFinalizados.eliminarUltimoFinalizado();
            
            hasta.ingresarTramite(exp);
        }
    }
    
    public void moverExpedienteAntiguedad(String nombreDependenciaDesde, String nombreDependenciaHasta){
        Dependencia desde = this.obtenerDependencia(nombreDependenciaDesde);
        Dependencia hasta = this.obtenerDependencia(nombreDependenciaHasta);
        
        if (desde != null && hasta != null) {
            desde.finalizarTramiteAntiguedad();
            Expediente exp = ExpedientesFinalizados.eliminarUltimoFinalizado();
            
            hasta.ingresarTramite(exp);
        }
    }
    
    public void moverExpedientePrioridad(String nombreDependenciaDesde, String nombreDependenciaHasta){
        Dependencia desde = this.obtenerDependencia(nombreDependenciaDesde);
        Dependencia hasta = this.obtenerDependencia(nombreDependenciaHasta);
        
        if (desde != null && hasta != null) {
            desde.finalizarTramitePrioridad();
            Expediente exp = ExpedientesFinalizados.eliminarUltimoFinalizado();
            
            hasta.ingresarTramite(exp);
        }
    }

    public String getNomUsuario() {
        return nomUsuario;
    }

    public String getContraseña() {
        return contraseña;
    }
}

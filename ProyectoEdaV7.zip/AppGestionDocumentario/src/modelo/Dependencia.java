package modelo;
    import java.util.Date;
    import java.util.HashSet;
    import java.util.Set;
    import tda.*;


public class Dependencia {
    private String nombre;
    private Cola<Expediente> expedientes;
    
    public Dependencia(String nombre){
        this.expedientes = new Cola();
        this.nombre = nombre;
    }
    
    public void ingresarTramite(int prioridad, Usuario interesado, String asunto){
        Expediente nuevo = new Expediente(prioridad, interesado, asunto);
        nuevo.setDepenActual(this);
        this.expedientes.encolar(nuevo);
    }
    
    public void ingresarTramite(Expediente exp){
        exp.setDepenActual(this);
        this.expedientes.encolar(exp);
    }
    
    public void finalizarTramiteConID(String UID){
        Cola<Expediente> aux = new Cola();
        Expediente resp = null;
        while(!this.expedientes.esVacia()){
            Expediente actual = this.expedientes.desencolar();
            if (actual.getID().equals(UID)) {
                resp = actual;
            }
            aux.encolar(actual);
        }
        while(!aux.esVacia()){
            this.expedientes.encolar(aux.desencolar());
        }
        if (resp != null) {
            Date horaFin = new Date();
            resp.setHoraFin(horaFin);
            ExpedientesFinalizados.ingresarFinalizado(resp);
        }
    }
    
    public void finalizarTramiteAntiguedad(){
        Expediente resp = this.expedientes.desencolar();
        Date horaFin = new Date();
        resp.setHoraFin(horaFin);
        ExpedientesFinalizados.ingresarFinalizado(resp);
    }
    
    public void finalizarTramitePrioridad(){
        Cola<Expediente> aux = new Cola();
        int prioridadMenor = 0;
        boolean primItera = true;
        while(!this.expedientes.esVacia()){
            Expediente actual = this.expedientes.desencolar();
            if(primItera){
                prioridadMenor = actual.getPrioridad();
                primItera = false;
            }
            if (actual.getPrioridad() < prioridadMenor && !primItera) {
                prioridadMenor = actual.getPrioridad();
            }
            aux.encolar(actual);
        }
        
        Expediente resp = null;
        boolean primResp = true;
        while(!aux.esVacia()){
            Expediente actual = aux.desencolar();
            if (actual.getPrioridad() == prioridadMenor && primResp) {
                resp = actual;
                primResp = false;
            }
            else{
                this.expedientes.encolar(actual);
            }
        }
        if (resp != null) {
            Date horaFin = new Date();
            resp.setHoraFin(horaFin);
            ExpedientesFinalizados.ingresarFinalizado(resp);
        }
    }
    
    public void verTramitesDepedencia(){
        String resp = "";
        Cola<Expediente> aux = new Cola();
        while(!this.expedientes.esVacia()){
            Expediente actual = this.expedientes.desencolar();
            resp += actual.getID() + " / " + this.nombre + " / " + actual.getHoraInicio() + " / " + actual.getPrioridad() + "\n";
            aux.encolar(actual);
        }
        while(!aux.esVacia()){
            this.expedientes.encolar(aux.desencolar());
        }
        System.out.println(resp);
    }

    public String getNombre() {
        return nombre;
    }
}
